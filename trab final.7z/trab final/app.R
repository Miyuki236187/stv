library(shiny)
library(stv)

# Define UI for app that draws a histogram ----
ui <- fluidPage(

  # App title ----
  titlePanel("Pacote de visualização de séries temporais"),


  # Sidebar layout with input and output definitions ----
  sidebarLayout(

    # Sidebar panel for inputs ----
    sidebarPanel(

      #dropdown
      selectInput("Dados", "Selecione os dados para simulação",
                  choices = c("euro", "mtcars", "iris")),

    ),

    # Main panel for displaying outputs ----
    mainPanel(
      tabsetPanel(
        tabPanel("ACF", textOutput("texto_acf"), plotOutput("acf")),
        tabPanel("PACF", textOutput("texto_pacf"), plotOutput("pacf")),
        tabPanel("Sequencia", plotOutput("seq")),
        tabPanel("Tabela", tableOutput("tabela"))
      )
    )
  )
)

# Define server logic required to draw a histogram ----
server <- function(input, output) {

  # Histogram of the Old Faithful Geyser Data ----
  # with requested number of bins
  # This expression that generates a histogram is wrapped in a call
  # to renderPlot to indicate that:
  #
  # 1. It is "reactive" and therefore should be automatically
  #    re-executed when inputs (input$bins) change
  # 2. Its output type is a plot
  output$texto_acf = renderText("O correlograma (ACF) é o gráfico utilizado em séries temporais
                                para traçar as autocorrelações em diversas defasagens.
                                A análise desse gráfico permite entender se a série é
                                aleatória ou possui alguma tendência ou sazonalidade.")

  output$texto_pacf = renderText("O correlograma parcial (PACF) é o gráfico utilizado em séries temporais
                                para traçar as autocorrelações em diversas defasagens, sem considerar os valores intermediárias.")


  output$tabela = renderTable({stv::stv_tabela(c(1,2,3,4,5))})

 teste <- data.frame(data = seq(1,1000), valor = rnorm(1000))

  output$seq = renderPlot({stv::stv_seq(teste, 'data', 'valor', anim = T)})

  output$distPlot <- renderPlot({

    x    <- faithful$waiting
    bins <- seq(min(x), max(x), length.out = input$bins + 1)

    hist(x, breaks = bins, col = "#007bc2", border = "white",
         xlab = "Waiting time to next eruption (in mins)",
         main = "Histogram of waiting times")

  })

}

# Run the application
shinyApp(ui = ui, server = server)

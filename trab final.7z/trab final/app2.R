library(shiny)
library(shinydashboard)
library(wooldridge)
install.packages("gifsky", repos = "http://cran.rstudio.com")

# Define UI for application that draws a histogram
ui <- dashboardPage(skin = "purple",
                    dashboardHeader(
                      title = "Pacote stv",
                      titleWidth = 300
                    ),
                    dashboardSidebar(
                      width = 300,
                      sidebarMenu(
                        menuItem("Introdução", tabName = "pagina1"),
                        menuItem("stv_seq", tabName = "pagina2"),
                        menuItem("stv_acf", tabName = "pagina3"),
                        menuItem("stv_pacf", tabName = "pagina4"),
                        menuItem("stv_tabela", tabName = "pagina5")
                      )
                    ),
                    dashboardBody(
                      tabItems(
                        #-----------------------------------
                        #-----------------------PAGINA INTRO
                        tabItem(
                          tabName = "pagina1",
                          h2("Introdução"),
                          sidebarLayout(
                            sidebarPanel(
                              width = 5,
                              title = "Escolha do conjunto de dados",
                                   id = "tabset2",
                                   fluidRow(
                                     box(
                                       tableOutput("tableprev1"),
                                       selectInput(inputId = "dados",
                                                   label = "dados",
                                                   choices = c("consump","okun")
                                       ),
                                       width = 12
                                     ),
                                     box(
                                       textOutput("texto_intro"),
                                       width = 12
                                     ),
                                     box(
                                       title = "Sequência",
                                       plotOutput("IntSeq", height = 300),
                                       width = 12
                                     )

                                   )
                            ),
                          mainPanel(
                            width = 5,
                            fluidRow(
                              box(
                                title = "ACF",
                                plotOutput("intro_acf", height = 300),
                                width = 12
                              ),
                              box(
                                title = "PACF",
                                plotOutput("intro_pacf", height = 300),
                                width = 12
                              )
                            )
                          )
                        )),
                        #-----------------------------------
                        #------------------PAGINA SEQUENCIAL
                        tabItem(
                          tabName = "pagina2",
                          h2("Função stv_seq"),
                          sidebarLayout(
                            sidebarPanel(title = "Gráfico de Sequência",
                                   id = "id3",
                                   fluidRow(
                                     box(
                                       textOutput("texto_seq"),
                                       width = 12
                                     ),
                                     box(
                                       title = "Uso",
                                       verbatimTextOutput("uso_seq"),
                                       width = 12
                                     )
                                   )
                            ),
                            mainPanel(
                              box(
                                title = "Sequêncial",
                                plotOutput("seq"),
                                width = 12
                              )
                            )
                          )
                        ),
                        #-----------------------------------
                        #-------------------------PAGINA ACF
                        tabItem(
                          tabName = "pagina3",
                          h2("Função stv_acf"),
                          sidebarLayout(
                            sidebarPanel(title = "Gráfico ACF",
                                   id = "id2",
                                   fluidRow(
                                     box(
                                       textOutput("texto_acf"),
                                       width = 12
                                     ),
                                     box(
                                       title = "Uso",
                                       verbatimTextOutput("uso_acf"),
                                       width = 12
                                     )
                                   )

                            ),
                            mainPanel(
                              box(
                              title = "Auto Correlation Function",
                              plotOutput("acf"),
                              width = 12
                            ))
                          )
                        ),
                        #-----------------------------------
                        #------------------------PAGINA PACF
                        tabItem(
                          tabName = "pagina4",
                          h2("Função stv_pacf"),
                          sidebarLayout(
                            sidebarPanel(title = "Gráfico PACF",
                                   id = "id3",
                                   fluidRow(
                                     box(
                                       textOutput("texto_pacf"),
                                       width = 12
                                     ),
                                     box(
                                       title = "Uso",
                                       verbatimTextOutput("uso_pacf"),
                                        width = 12
                                     )
                                   )
                            ),
                            mainPanel(
                              box(
                                title = "Partial Auto Correlation Function",
                                plotOutput("pacf"),
                                width = 12
                              )
                            )
                          )
                        ),
                        #-----------------------------------
                        #----------------------PAGINA TABELA
                        tabItem(
                          tabName = "pagina5",
                          h2("Função stv_tabela"),
                          sidebarLayout(
                            sidebarPanel(title = "Principais estatísticas",
                                   id = "id3",
                                   fluidRow(
                                     box(
                                       textOutput("texto_tabela"),
                                       width = 12
                                     ),
                                     box(
                                       title = "Uso",
                                       verbatimTextOutput("uso_tabela"),
                                       width = 12
                                     )
                                   )
                            ),
                            mainPanel(
                              box(
                              title = "Tabela com principais estísticas",
                              tableOutput("tabela"),
                              width = 12
                            ))
                          )
                        )
                      )
                    )
)

server <- function(input, output) {
  #-----------------------------------
  #------------------Página Introdução
  data <- eventReactive(input$dados,{
    data <- parse(text = input$dados)
    x <- eval(data)
    dados <- x[,c(1,3)]
    colnames(dados)[1] <- "data"
    colnames(dados)[2] <- "valor"
    dados
  })




  output$IntSeq <- renderPlot({
    dados <- data()
    plot(dados, type = "l")
  })

  output$texto_intro = renderText({"O pacote stv visa gerar gráficos mais bonitos na análise de
                                   séries temporais. Abaixo podemos ver os gráficos de funções do
                                   próprio R. Para alguem que não tem afinidade com a linguagem,
                                   editá-los afim de melhorar a visualização é uma tarefa difícil.
                                   Desta forma criamos um pacote que faz isso de maneira mais
                                   simples e direta.  "})

  output$intro_acf = renderPlot({
    dados = data()
    dados = dados[,2]
    acf(dados)})
  output$intro_pacf = renderPlot({
    dados = data()
    dados = dados[,2]
    pacf(dados)})

  #-----------------------------------
  #--------------------------PAGINA SEQ
  output$uso_seq = renderText({paste("stv_seq(dados, x, y, eixo_x, eixo_y, titulo, bolinha, cor, tema, anim)",
                                     " ",
                                     "- dados: objeto do tipo data.frame;",
                                     "- x: nome da coluna no data frame dos dados do eixo x",
                                     "- y: nome da coluna no data frame dos dados do eixo y",
                                     "- eixo_x: denominacao no eixo x, default é o nome da coluna informado no parametro x",
                                     "- eixo_y: denominacao no eixo y, default é o nome da coluna informado no parametro y",
                                     "- titulo: objeto do tipo character, default = \"Grafico de Sequencia\";",
                                     "- bolinha: gr?fico ter? as observa??es marcadas por bolinhas ou n?o, default ? sem bolinha (boleano);",
                                     "- cor: cor da linha e das bolinhas (character), default ? preto;",
                                     "- tema: tema do gráfico, default = claro",
                                     "- anim: se o grafico sera animado ou nao (boleano).",
                                     sep="\n")})

  output$texto_seq = renderText("O gráfico sequencial de séries temporais ilustra o comportamento da série ao longo do tempo. Mostra a distribuição dos dados.")
  output$seq = renderPlot({



    dados = data()
    stv::stv_seq(dados, 'data', 'valor', anim = F)

    })
  #-----------------------------------
  #-------------------------PAGINA ACF
  dados =
  output$uso_acf = renderText({paste("stv_acf(vetor, cor, bolinha, linha, lagg, tema)",
                                     " ",
                                     "- vetor: vetor da série para o cálculo da ACF (numeric);",
                                     "- cor: cor das bolinhas e das linhas (character), default é preto;",
                                     "- bolinha: gráfico terá os valores marcados por bolinhas ou não, default é sem bolinhas (boleano);",
                                     "- linha: espessura da linha valor (numeric) da espessura da linha, default é 1;",
                                     "- lagg: lag.max do gráfico (integer), default é 10;",
                                     "- tema: tema do gráfico, default é 'claro'.",
                                     sep="\n")})
  output$texto_acf = renderText("O correlograma (ACF) é o gráfico utilizado em séries temporais
                                para traçar as autocorrelações em diversas defasagens.
                                A análise desse gráfico permite entender se a série é
                                aleatória ou possui alguma tendência ou sazonalidade.")
  output$acf = renderPlot({
    dados = data()
    dados = dados[,2]
    stv::stv_acf(dados, 'purple', T)})

  #-----------------------------------
  #------------------------PAGINA PACF
  output$uso_pacf = renderText({paste("stv_pacf(vetor, cor, bolinha, linha, lagg, tema)",
                                     " ",
                                     "- vetor: vetor da série para o cálculo da ACF (numeric);",
                                     "- cor: cor das bolinhas e das linhas (character), default é preto;",
                                     "- bolinha: gráfico terá os valores marcados por bolinhas ou não, default é sem bolinhas (boleano);",
                                     "- linha: espessura da linha valor (numeric) da espessura da linha, default é 1;",
                                     "- lagg: lag.max do gráfico (integer), default é 10;",
                                     "- tema: tema do gráfico, default é 'claro'.",
                                     sep="\n")})
  output$texto_pacf = renderText("O correlograma parcial (PACF) é o gráfico utilizado em séries temporais para traçar as autocorrelações em diversas defasagens, sem considerar os valores intermediárias.")
  output$pacf = renderPlot({
    dados = data()
    dados = dados[,2]
    stv::stv_pacf(dados, 'purple', T)})


  #-----------------------------------
  #----------------------PAGINA TABELA
  output$uso_tabela = renderText({paste("stv_tabela(dados)",
                                      " ",
                                      "- dados: dados da série para o cálculo da ACF (numeric);",
                                      sep="\n")})
  output$texto_tabela = renderText("Tabela com as principais estatísticas dos dados da série temporal: mínimo, máximo, média e desvio padrão.")
  output$tabela = renderTable({
    dados = data()
    dados = dados[,2]
    stv::stv_tabela(dados)})

}

# Run the application
shinyApp(ui = ui, server = server)

